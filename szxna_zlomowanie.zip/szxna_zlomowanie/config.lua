config = {}

-- do edycji
config.discordwebhook = ''
config.coords = {
	{x = 2341.46,  y = 3051.97,  z = 47.15},
}
-- do edycji